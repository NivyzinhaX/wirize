import { cn } from '@/lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export function Card({ children, className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-lg border bg-card p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:shadow-green-500/10",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}