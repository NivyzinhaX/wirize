import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

export function Contact() {
  return (
    <section id="contato" className="py-16 bg-muted/50">
      <div className="container px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Contato</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <div className="space-y-4">
              <form className="space-y-4">
                <div>
                  <Input placeholder="Nome" />
                </div>
                <div>
                  <Textarea placeholder="Mensagem" className="min-h-[120px]" />
                </div>
                <Button className="w-full">Enviar Mensagem</Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
