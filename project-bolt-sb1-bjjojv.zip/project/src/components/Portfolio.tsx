import { useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useInView } from '@/hooks/useInView';
import { cn } from '@/lib/utils';

const projects = [
  {
    title: 'Projeto 1',
    description: 'Descrição detalhada do projeto 1',
    image: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131',
    tags: ['Dança', 'Coreografia'],
  },
  {
    title: 'Projeto 2',
    description: 'Descrição detalhada do projeto 2',
    image: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131',
    tags: ['Consultoria', 'Gestão'],
  },
  {
    title: 'Projeto 3',
    description: 'Descrição detalhada do projeto 3',
    image: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131',
    tags: ['Tradução', 'Localização'],
  },
];

export function Portfolio() {
  const [ref, isInView] = useInView({ threshold: 0.1 });

  return (
    <section id="portfolio" className="py-16 overflow-hidden" ref={ref}>
      <div className="container px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Meu Portfólio</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Card 
              key={index} 
              className={cn(
                "group hover:shadow-lg transition-all duration-500 transform",
                isInView && "animate-in fade-in-50 slide-in-from-bottom-10",
                isInView && `delay-[${index * 200}ms]`
              )}
            >
              <CardHeader>
                <div className="overflow-hidden rounded-t-lg">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover transform group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <CardTitle className="mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </CardTitle>
                <CardDescription className="mb-4">{project.description}</CardDescription>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <Badge 
                      key={tag} 
                      variant="secondary"
                      className="group-hover:bg-primary/10 group-hover:text-primary transition-colors"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}