import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export function About() {
  return (
    <section id="sobre" className="py-16">
      <div className="container px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Sobre Mim</h2>
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <img
              src="https://i.postimg.cc/0Q1807PN/UOgF.gif"
              alt="Perfil"
              className="w-64 h-64 rounded-full object-cover"
            />
            <div>
              <p className="text-lg text-muted-foreground mb-4">
                Com mais de [X] anos de experiência em [área], tenho dedicado minha carreira a [objetivo/missão].
                Minha formação em [área] e especialização em [especialidade] me permitem oferecer um serviço único
                e personalizado para cada cliente.
              </p>
              <Button variant="outline" className="group">
                <Download className="mr-2 h-4 w-4 group-hover:-translate-y-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}