import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { useScrollTo } from '@/hooks/useScrollTo';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const scrollTo = useScrollTo();

  const menuItems = [
    { id: 'inicio', label: 'Início' },
    { id: 'portfolio', label: 'Portfólio' },
    { id: 'servicos', label: 'Serviços' },
    { id: 'sobre', label: 'Sobre' },
    { id: 'contato', label: 'Contato' },
  ];

  const handleClick = (id: string) => {
    scrollTo(id);
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-sm border-b border-green-500/20">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <button 
            onClick={() => handleClick('inicio')} 
            className="text-2xl font-bold text-green-500 hover:text-green-400 transition-colors"
          >
          MvzInDev
          </button>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleClick(item.id)}
                className="text-gray-400 hover:text-green-500 transition-colors hover:scale-105 transform"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-green-500"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={cn(
            'md:hidden absolute left-0 right-0 bg-background/95 border-b border-green-500/20',
            isMenuOpen ? 'block' : 'hidden'
          )}
        >
          <div className="flex flex-col space-y-4 p-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleClick(item.id)}
                className="text-gray-400 hover:text-green-500 transition-colors text-left"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>
    </header>
  );
}