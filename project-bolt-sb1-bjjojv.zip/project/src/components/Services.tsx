import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Music2, Languages, Lightbulb } from 'lucide-react';
import { useInView } from '@/hooks/useInView';
import { cn } from '@/lib/utils';

const services = [
  {
    icon: Music2,
    title: 'Aulas de Dança',
    description: 'Aulas personalizadas de diversos estilos de dança para todos os níveis.',
  },
  {
    icon: Languages,
    title: 'Tradução',
    description: 'Serviços profissionais de tradução em múltiplos idiomas.',
  },
  {
    icon: Lightbulb,
    title: 'Consultoria',
    description: 'Consultoria especializada para projetos criativos e culturais.',
  },
];

export function Services() {
  const [ref, isInView] = useInView({ threshold: 0.1 });

  return (
    <section id="servicos" className="relative py-16 overflow-hidden" ref={ref}>
      {/* Hack Logo Background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5">
        <div 
          className="w-[800px] h-[800px] transform rotate-12 animate-float"
          style={{
            background: 'linear-gradient(45deg, rgba(74, 222, 128, 0.1), transparent)',
          }}
        >
          <svg viewBox="0 0 400 400" className="w-full h-full">
            <path
              d="M200 50 L350 150 L350 250 L200 350 L50 250 L50 150 Z"
              className="stroke-green-500"
              fill="none"
              strokeWidth="2"
            />
            <path
              d="M140 200 L260 200"
              className="stroke-green-500"
              strokeWidth="2"
            />
          </svg>
        </div>
      </div>

      <div className="container px-4 relative z-10">
        <h2 className="text-3xl font-bold text-center mb-12">Serviços</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className={cn(
                "group hover:-translate-y-2 hover:shadow-lg transition-all duration-500 backdrop-blur-sm bg-background/50",
                isInView && "animate-in fade-in-50 slide-in-from-bottom-10",
                isInView && `delay-[${index * 200}ms]`
              )}
            >
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                  <service.icon className="w-6 h-6 text-primary group-hover:rotate-12 transition-transform duration-500" />
                </div>
                <CardTitle className="group-hover:text-primary transition-colors">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="group-hover:text-muted-foreground transition-colors">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}