import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { useScrollTo } from '@/hooks/useScrollTo';

export function Hero() {
  const scrollTo = useScrollTo();

  return (
    <section id="inicio" className="min-h-screen flex items-center justify-center pt-16">
      <div className="container px-4 py-16 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent animate-float">
          Olá, eu sou Mvzin
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Profissional apaixonado por criar experiências únicas através da sites & Bots
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button 
            size="lg" 
            className="group bg-green-600 hover:bg-green-700 hover:scale-105 transition-all duration-300"
            onClick={() => scrollTo('portfolio')}
          >
            Ver Portfólio
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            size="lg" 
            variant="outline"
            onClick={() => scrollTo('contato')}
            className="border-green-500 text-green-500 hover:bg-green-500/10 hover:scale-105 transition-all duration-300"
          >
            Entre em Contato
          </Button>
        </div>
      </div>
    </section>
  );
}